﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnboardingExperience
{
    public class User
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public bool IsAccountowner { get; set; }
        public int PinNumber { get; set; }

    }
    
    public string FirstName { get}
      //lost// }
}

     


